clear all;
close all;

numberOfHiddenNeurons = 9;
numberOfOutputs = 2;
sigmoidConstant = 1;
weights = csvread('BestWeights');
createTestPlot = 'yes';

iDataSet = 2;
iSlope = 1;

fitness = TruckModel(weights, numberOfHiddenNeurons, numberOfOutputs,...
    sigmoidConstant, iDataSet, iSlope, createTestPlot);