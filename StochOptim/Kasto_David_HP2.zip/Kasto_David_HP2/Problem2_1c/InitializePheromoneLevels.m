function pheromoneLevel = InitializePheromoneLevels(numberOfCities, tau0)
    pheromoneLevel = ones(numberOfCities) * tau0;
end